﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DatabaseTVP;

namespace SfDesk
{
    public class PageAuth
    {
        public static bool URM_AuthenticatePage(int UserId, string PageName)
        {
          
            return true;
        }

    }

}