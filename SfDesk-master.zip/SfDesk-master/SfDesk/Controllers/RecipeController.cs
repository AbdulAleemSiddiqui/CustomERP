﻿using SfDesk.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SfDesk.Controllers
{
   // [Session]
    //public class RecipeController : Controller
    //{
    //    // GET: Recipe
    //    public ActionResult Index(int pid)
    //    {

    //        return Json(new Recipe() {R_ID =pid }.Recipe_Get_By_Product(), JsonRequestBehavior.AllowGet);
    //    }
    //    [HttpPost]
    //    public ActionResult Add(Recipe r)
    //        {
    //        r.ID = int.Parse(r.E_ID.Remove(0,1));
    //        r.Recipe_Add();
    //        return Json("Add");
    //    }
    //    public ActionResult Add()
    //    {
            
    //        return View();
    //    }
    //    [HttpPost]
    //    public ActionResult Update(Recipe r)
    //    {
    //        //r.ID = int.Parse(r.Name);
    //        r.Recipe_Update();
    //        return Json("Update");
    //    }
    //    public ActionResult Delete(Recipe r)
    //    {
    //        //r.ID = int.Parse(r.Name);
    //        r.Recipe_Delete();
    //        return Json("Add");
    //    }
    //}
}